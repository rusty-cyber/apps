﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Btnok = New System.Windows.Forms.Button()
        Me.Txtcount = New System.Windows.Forms.TextBox()
        Me.LblCounter1 = New System.Windows.Forms.Label()
        Me.LblCounter2 = New System.Windows.Forms.Label()
        Me.LblCounter3 = New System.Windows.Forms.Label()
        Me.LblCounter4 = New System.Windows.Forms.Label()
        Me.LblCounter5 = New System.Windows.Forms.Label()
        Me.LblCounter6 = New System.Windows.Forms.Label()
        Me.LblCounter7 = New System.Windows.Forms.Label()
        Me.LblCounter8 = New System.Windows.Forms.Label()
        Me.LblCounter9 = New System.Windows.Forms.Label()
        Me.LblCounter10 = New System.Windows.Forms.Label()
        Me.LblCounter15 = New System.Windows.Forms.Label()
        Me.LblCounter14 = New System.Windows.Forms.Label()
        Me.LblCounter13 = New System.Windows.Forms.Label()
        Me.LblCounter12 = New System.Windows.Forms.Label()
        Me.LblCounter11 = New System.Windows.Forms.Label()
        Me.LblCounter16 = New System.Windows.Forms.Label()
        Me.LblCounter17 = New System.Windows.Forms.Label()
        Me.LblCounter18 = New System.Windows.Forms.Label()
        Me.LblCounter19 = New System.Windows.Forms.Label()
        Me.PicCounter = New System.Windows.Forms.PictureBox()
        Me.LblCounter20 = New System.Windows.Forms.Label()
        Me.LblCounter21 = New System.Windows.Forms.Label()
        Me.LblCounter22 = New System.Windows.Forms.Label()
        Me.LblCounter23 = New System.Windows.Forms.Label()
        Me.LblCounter24 = New System.Windows.Forms.Label()
        Me.LblCounter25 = New System.Windows.Forms.Label()
        CType(Me.PicCounter, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Btnok
        '
        Me.Btnok.Location = New System.Drawing.Point(526, 381)
        Me.Btnok.Name = "Btnok"
        Me.Btnok.Size = New System.Drawing.Size(139, 57)
        Me.Btnok.TabIndex = 1
        Me.Btnok.Text = "ok"
        Me.Btnok.UseVisualStyleBackColor = True
        '
        'Txtcount
        '
        Me.Txtcount.Location = New System.Drawing.Point(121, 399)
        Me.Txtcount.Name = "Txtcount"
        Me.Txtcount.Size = New System.Drawing.Size(217, 20)
        Me.Txtcount.TabIndex = 2
        '
        'LblCounter1
        '
        Me.LblCounter1.BackColor = System.Drawing.Color.DarkRed
        Me.LblCounter1.Location = New System.Drawing.Point(257, 310)
        Me.LblCounter1.Name = "LblCounter1"
        Me.LblCounter1.Size = New System.Drawing.Size(30, 30)
        Me.LblCounter1.TabIndex = 3
        Me.LblCounter1.Visible = False
        '
        'LblCounter2
        '
        Me.LblCounter2.BackColor = System.Drawing.Color.DarkRed
        Me.LblCounter2.Location = New System.Drawing.Point(335, 310)
        Me.LblCounter2.Name = "LblCounter2"
        Me.LblCounter2.Size = New System.Drawing.Size(30, 30)
        Me.LblCounter2.TabIndex = 4
        Me.LblCounter2.Visible = False
        '
        'LblCounter3
        '
        Me.LblCounter3.BackColor = System.Drawing.Color.DarkRed
        Me.LblCounter3.Location = New System.Drawing.Point(405, 310)
        Me.LblCounter3.Name = "LblCounter3"
        Me.LblCounter3.Size = New System.Drawing.Size(30, 30)
        Me.LblCounter3.TabIndex = 5
        Me.LblCounter3.Visible = False
        '
        'LblCounter4
        '
        Me.LblCounter4.BackColor = System.Drawing.Color.DarkRed
        Me.LblCounter4.Location = New System.Drawing.Point(468, 301)
        Me.LblCounter4.Name = "LblCounter4"
        Me.LblCounter4.Size = New System.Drawing.Size(30, 30)
        Me.LblCounter4.TabIndex = 6
        Me.LblCounter4.Visible = False
        '
        'LblCounter5
        '
        Me.LblCounter5.BackColor = System.Drawing.Color.DarkRed
        Me.LblCounter5.Location = New System.Drawing.Point(545, 301)
        Me.LblCounter5.Name = "LblCounter5"
        Me.LblCounter5.Size = New System.Drawing.Size(30, 30)
        Me.LblCounter5.TabIndex = 7
        Me.LblCounter5.Visible = False
        '
        'LblCounter6
        '
        Me.LblCounter6.BackColor = System.Drawing.Color.DarkRed
        Me.LblCounter6.Location = New System.Drawing.Point(534, 239)
        Me.LblCounter6.Name = "LblCounter6"
        Me.LblCounter6.Size = New System.Drawing.Size(30, 30)
        Me.LblCounter6.TabIndex = 8
        Me.LblCounter6.Visible = False
        '
        'LblCounter7
        '
        Me.LblCounter7.BackColor = System.Drawing.Color.DarkRed
        Me.LblCounter7.Location = New System.Drawing.Point(468, 239)
        Me.LblCounter7.Name = "LblCounter7"
        Me.LblCounter7.Size = New System.Drawing.Size(30, 30)
        Me.LblCounter7.TabIndex = 9
        Me.LblCounter7.Visible = False
        '
        'LblCounter8
        '
        Me.LblCounter8.BackColor = System.Drawing.Color.DarkRed
        Me.LblCounter8.Location = New System.Drawing.Point(405, 239)
        Me.LblCounter8.Name = "LblCounter8"
        Me.LblCounter8.Size = New System.Drawing.Size(30, 30)
        Me.LblCounter8.TabIndex = 10
        Me.LblCounter8.Visible = False
        '
        'LblCounter9
        '
        Me.LblCounter9.BackColor = System.Drawing.Color.DarkRed
        Me.LblCounter9.Location = New System.Drawing.Point(335, 239)
        Me.LblCounter9.Name = "LblCounter9"
        Me.LblCounter9.Size = New System.Drawing.Size(30, 30)
        Me.LblCounter9.TabIndex = 11
        Me.LblCounter9.Visible = False
        '
        'LblCounter10
        '
        Me.LblCounter10.BackColor = System.Drawing.Color.DarkRed
        Me.LblCounter10.Location = New System.Drawing.Point(257, 239)
        Me.LblCounter10.Name = "LblCounter10"
        Me.LblCounter10.Size = New System.Drawing.Size(30, 30)
        Me.LblCounter10.TabIndex = 12
        Me.LblCounter10.Visible = False
        '
        'LblCounter15
        '
        Me.LblCounter15.BackColor = System.Drawing.Color.DarkRed
        Me.LblCounter15.Location = New System.Drawing.Point(545, 165)
        Me.LblCounter15.Name = "LblCounter15"
        Me.LblCounter15.Size = New System.Drawing.Size(30, 30)
        Me.LblCounter15.TabIndex = 13
        Me.LblCounter15.Visible = False
        '
        'LblCounter14
        '
        Me.LblCounter14.BackColor = System.Drawing.Color.DarkRed
        Me.LblCounter14.Location = New System.Drawing.Point(468, 165)
        Me.LblCounter14.Name = "LblCounter14"
        Me.LblCounter14.Size = New System.Drawing.Size(30, 30)
        Me.LblCounter14.TabIndex = 14
        Me.LblCounter14.Visible = False
        '
        'LblCounter13
        '
        Me.LblCounter13.BackColor = System.Drawing.Color.DarkRed
        Me.LblCounter13.Location = New System.Drawing.Point(405, 165)
        Me.LblCounter13.Name = "LblCounter13"
        Me.LblCounter13.Size = New System.Drawing.Size(30, 30)
        Me.LblCounter13.TabIndex = 15
        Me.LblCounter13.Visible = False
        '
        'LblCounter12
        '
        Me.LblCounter12.BackColor = System.Drawing.Color.DarkRed
        Me.LblCounter12.Location = New System.Drawing.Point(335, 165)
        Me.LblCounter12.Name = "LblCounter12"
        Me.LblCounter12.Size = New System.Drawing.Size(30, 30)
        Me.LblCounter12.TabIndex = 16
        Me.LblCounter12.Visible = False
        '
        'LblCounter11
        '
        Me.LblCounter11.BackColor = System.Drawing.Color.DarkRed
        Me.LblCounter11.Location = New System.Drawing.Point(257, 165)
        Me.LblCounter11.Name = "LblCounter11"
        Me.LblCounter11.Size = New System.Drawing.Size(30, 30)
        Me.LblCounter11.TabIndex = 17
        Me.LblCounter11.Visible = False
        '
        'LblCounter16
        '
        Me.LblCounter16.BackColor = System.Drawing.Color.DarkRed
        Me.LblCounter16.Location = New System.Drawing.Point(545, 97)
        Me.LblCounter16.Name = "LblCounter16"
        Me.LblCounter16.Size = New System.Drawing.Size(30, 30)
        Me.LblCounter16.TabIndex = 18
        Me.LblCounter16.Visible = False
        '
        'LblCounter17
        '
        Me.LblCounter17.BackColor = System.Drawing.Color.DarkRed
        Me.LblCounter17.Location = New System.Drawing.Point(468, 97)
        Me.LblCounter17.Name = "LblCounter17"
        Me.LblCounter17.Size = New System.Drawing.Size(30, 30)
        Me.LblCounter17.TabIndex = 19
        Me.LblCounter17.Visible = False
        '
        'LblCounter18
        '
        Me.LblCounter18.BackColor = System.Drawing.Color.DarkRed
        Me.LblCounter18.Location = New System.Drawing.Point(405, 97)
        Me.LblCounter18.Name = "LblCounter18"
        Me.LblCounter18.Size = New System.Drawing.Size(30, 30)
        Me.LblCounter18.TabIndex = 20
        Me.LblCounter18.Visible = False
        '
        'LblCounter19
        '
        Me.LblCounter19.BackColor = System.Drawing.Color.DarkRed
        Me.LblCounter19.Location = New System.Drawing.Point(335, 97)
        Me.LblCounter19.Name = "LblCounter19"
        Me.LblCounter19.Size = New System.Drawing.Size(30, 30)
        Me.LblCounter19.TabIndex = 21
        Me.LblCounter19.Visible = False
        '
        'PicCounter
        '
        Me.PicCounter.Image = Global.AppCounter1.My.Resources.Resources.GameBoard
        Me.PicCounter.Location = New System.Drawing.Point(82, 29)
        Me.PicCounter.Name = "PicCounter"
        Me.PicCounter.Size = New System.Drawing.Size(676, 323)
        Me.PicCounter.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PicCounter.TabIndex = 0
        Me.PicCounter.TabStop = False
        '
        'LblCounter20
        '
        Me.LblCounter20.BackColor = System.Drawing.Color.DarkRed
        Me.LblCounter20.Location = New System.Drawing.Point(257, 106)
        Me.LblCounter20.Name = "LblCounter20"
        Me.LblCounter20.Size = New System.Drawing.Size(30, 30)
        Me.LblCounter20.TabIndex = 22
        Me.LblCounter20.Visible = False
        '
        'LblCounter21
        '
        Me.LblCounter21.BackColor = System.Drawing.Color.DarkRed
        Me.LblCounter21.Location = New System.Drawing.Point(257, 45)
        Me.LblCounter21.Name = "LblCounter21"
        Me.LblCounter21.Size = New System.Drawing.Size(30, 30)
        Me.LblCounter21.TabIndex = 23
        Me.LblCounter21.Visible = False
        '
        'LblCounter22
        '
        Me.LblCounter22.BackColor = System.Drawing.Color.DarkRed
        Me.LblCounter22.Location = New System.Drawing.Point(335, 45)
        Me.LblCounter22.Name = "LblCounter22"
        Me.LblCounter22.Size = New System.Drawing.Size(30, 30)
        Me.LblCounter22.TabIndex = 24
        Me.LblCounter22.Visible = False
        '
        'LblCounter23
        '
        Me.LblCounter23.BackColor = System.Drawing.Color.DarkRed
        Me.LblCounter23.Location = New System.Drawing.Point(405, 45)
        Me.LblCounter23.Name = "LblCounter23"
        Me.LblCounter23.Size = New System.Drawing.Size(30, 30)
        Me.LblCounter23.TabIndex = 25
        Me.LblCounter23.Visible = False
        '
        'LblCounter24
        '
        Me.LblCounter24.BackColor = System.Drawing.Color.DarkRed
        Me.LblCounter24.Location = New System.Drawing.Point(477, 45)
        Me.LblCounter24.Name = "LblCounter24"
        Me.LblCounter24.Size = New System.Drawing.Size(30, 30)
        Me.LblCounter24.TabIndex = 26
        Me.LblCounter24.Visible = False
        '
        'LblCounter25
        '
        Me.LblCounter25.BackColor = System.Drawing.Color.DarkRed
        Me.LblCounter25.Location = New System.Drawing.Point(545, 45)
        Me.LblCounter25.Name = "LblCounter25"
        Me.LblCounter25.Size = New System.Drawing.Size(30, 30)
        Me.LblCounter25.TabIndex = 27
        Me.LblCounter25.Visible = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.LblCounter25)
        Me.Controls.Add(Me.LblCounter24)
        Me.Controls.Add(Me.LblCounter23)
        Me.Controls.Add(Me.LblCounter22)
        Me.Controls.Add(Me.LblCounter21)
        Me.Controls.Add(Me.LblCounter20)
        Me.Controls.Add(Me.LblCounter19)
        Me.Controls.Add(Me.LblCounter18)
        Me.Controls.Add(Me.LblCounter17)
        Me.Controls.Add(Me.LblCounter16)
        Me.Controls.Add(Me.LblCounter11)
        Me.Controls.Add(Me.LblCounter12)
        Me.Controls.Add(Me.LblCounter13)
        Me.Controls.Add(Me.LblCounter14)
        Me.Controls.Add(Me.LblCounter15)
        Me.Controls.Add(Me.LblCounter10)
        Me.Controls.Add(Me.LblCounter9)
        Me.Controls.Add(Me.LblCounter8)
        Me.Controls.Add(Me.LblCounter7)
        Me.Controls.Add(Me.LblCounter6)
        Me.Controls.Add(Me.LblCounter5)
        Me.Controls.Add(Me.LblCounter4)
        Me.Controls.Add(Me.LblCounter3)
        Me.Controls.Add(Me.LblCounter2)
        Me.Controls.Add(Me.LblCounter1)
        Me.Controls.Add(Me.Txtcount)
        Me.Controls.Add(Me.Btnok)
        Me.Controls.Add(Me.PicCounter)
        Me.Name = "Form1"
        Me.Text = "snakes and ladders"
        CType(Me.PicCounter, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Btnok As Button
    Friend WithEvents Txtcount As TextBox
    Friend WithEvents LblCounter1 As Label
    Friend WithEvents LblCounter2 As Label
    Friend WithEvents LblCounter3 As Label
    Friend WithEvents LblCounter4 As Label
    Friend WithEvents LblCounter5 As Label
    Friend WithEvents LblCounter6 As Label
    Friend WithEvents LblCounter7 As Label
    Friend WithEvents LblCounter8 As Label
    Friend WithEvents LblCounter9 As Label
    Friend WithEvents LblCounter10 As Label
    Friend WithEvents LblCounter15 As Label
    Friend WithEvents LblCounter14 As Label
    Friend WithEvents LblCounter13 As Label
    Friend WithEvents LblCounter12 As Label
    Friend WithEvents LblCounter11 As Label
    Friend WithEvents LblCounter16 As Label
    Friend WithEvents LblCounter17 As Label
    Friend WithEvents LblCounter18 As Label
    Friend WithEvents LblCounter19 As Label
    Friend WithEvents PicCounter As PictureBox
    Friend WithEvents LblCounter20 As Label
    Friend WithEvents LblCounter21 As Label
    Friend WithEvents LblCounter22 As Label
    Friend WithEvents LblCounter23 As Label
    Friend WithEvents LblCounter24 As Label
    Friend WithEvents LblCounter25 As Label
End Class
