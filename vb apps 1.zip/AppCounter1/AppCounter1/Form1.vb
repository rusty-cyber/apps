﻿Public Class Form1

    Dim intScore As String
    Private Sub Btnok_Click(sender As Object, e As EventArgs) Handles Btnok.Click
        Dim intValue As Integer
        Dim strcountername As String


        'MAKE THE PRWVOUS COUNTER VISABLE
        If intScore > 0 Then
            strcountername = "LblCounter" & intScore.ToString
            Me.Controls(strcountername).Visible = False
        End If

        If intScore > 25 Then


        Else
            intScore = 25
            strcountername = "LblCounter" & intScore.ToString
            Me.Controls(strcountername).Visible = False



        End If








        intValue = Val(Txtcount.Text)
        intScore += intValue

        Call Snakes()

        Call ladders()

        strcountername = "LblCounter" & intScore.ToString


        Me.Controls(strcountername).Visible = True




    End Sub

    Private Sub Snakes()
        If intScore = 10 Then
            intScore -= 5
        End If

        If intScore = 24 Then
            intScore -= 13
        End If
    End Sub

    Private Sub ladders()
        If intScore = 3 Then
            intScore += 9

        End If

        If intScore = 13 Then
            intScore += 3
        End If
    End Sub
End Class
