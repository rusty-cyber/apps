﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Txttimes = New System.Windows.Forms.TextBox()
        Me.Txtstart = New System.Windows.Forms.TextBox()
        Me.Txtend = New System.Windows.Forms.TextBox()
        Me.Btnmultiply = New System.Windows.Forms.Button()
        Me.listresult = New System.Windows.Forms.ListBox()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(157, 45)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(93, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "which times tables"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(183, 90)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(39, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "start at"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(186, 138)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(37, 13)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "end at"
        '
        'Txttimes
        '
        Me.Txttimes.Location = New System.Drawing.Point(256, 38)
        Me.Txttimes.Name = "Txttimes"
        Me.Txttimes.Size = New System.Drawing.Size(100, 20)
        Me.Txttimes.TabIndex = 3
        '
        'Txtstart
        '
        Me.Txtstart.Location = New System.Drawing.Point(256, 87)
        Me.Txtstart.Name = "Txtstart"
        Me.Txtstart.Size = New System.Drawing.Size(100, 20)
        Me.Txtstart.TabIndex = 4
        '
        'Txtend
        '
        Me.Txtend.Location = New System.Drawing.Point(256, 135)
        Me.Txtend.Name = "Txtend"
        Me.Txtend.Size = New System.Drawing.Size(100, 20)
        Me.Txtend.TabIndex = 5
        '
        'Btnmultiply
        '
        Me.Btnmultiply.Location = New System.Drawing.Point(181, 195)
        Me.Btnmultiply.Name = "Btnmultiply"
        Me.Btnmultiply.Size = New System.Drawing.Size(256, 40)
        Me.Btnmultiply.TabIndex = 6
        Me.Btnmultiply.Text = "multiply"
        Me.Btnmultiply.UseVisualStyleBackColor = True
        '
        'listresult
        '
        Me.listresult.FormattingEnabled = True
        Me.listresult.Location = New System.Drawing.Point(192, 273)
        Me.listresult.Name = "listresult"
        Me.listresult.Size = New System.Drawing.Size(276, 160)
        Me.listresult.TabIndex = 7
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.listresult)
        Me.Controls.Add(Me.Btnmultiply)
        Me.Controls.Add(Me.Txtend)
        Me.Controls.Add(Me.Txtstart)
        Me.Controls.Add(Me.Txttimes)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Txttimes As TextBox
    Friend WithEvents Txtstart As TextBox
    Friend WithEvents Txtend As TextBox
    Friend WithEvents Btnmultiply As Button
    Friend WithEvents listresult As ListBox
End Class
