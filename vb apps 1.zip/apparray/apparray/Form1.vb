﻿Public Class Form1
    Private Sub Btnmultiply_Click(sender As Object, e As EventArgs) Handles Btnmultiply.Click
        Dim intnumber() As Integer
        Dim intmultiplier As Integer





        intmultiplier = Txttimes.Text



        For i = 0 To 10

            intnumber(i) = i * intmultiplier
            listresult.Items.Add(intmultiplier.ToString & " times" & i & " = " & intnumber(i))

        Next

    End Sub
End Class
