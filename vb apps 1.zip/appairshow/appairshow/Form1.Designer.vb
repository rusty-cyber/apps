﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Picballon = New System.Windows.Forms.PictureBox()
        Me.Btnball = New System.Windows.Forms.Button()
        Me.Picplane = New System.Windows.Forms.PictureBox()
        Me.Btngo = New System.Windows.Forms.Button()
        Me.Pichella = New System.Windows.Forms.PictureBox()
        Me.Btnhover = New System.Windows.Forms.Button()
        CType(Me.Picballon, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Picplane, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Pichella, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Picballon
        '
        Me.Picballon.Image = Global.appairshow.My.Resources.Resources.hot_air_balloon
        Me.Picballon.Location = New System.Drawing.Point(26, 189)
        Me.Picballon.Name = "Picballon"
        Me.Picballon.Size = New System.Drawing.Size(109, 179)
        Me.Picballon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.Picballon.TabIndex = 0
        Me.Picballon.TabStop = False
        '
        'Btnball
        '
        Me.Btnball.BackColor = System.Drawing.Color.Lime
        Me.Btnball.Location = New System.Drawing.Point(26, 509)
        Me.Btnball.Name = "Btnball"
        Me.Btnball.Size = New System.Drawing.Size(95, 35)
        Me.Btnball.TabIndex = 1
        Me.Btnball.Text = "ballon"
        Me.Btnball.UseVisualStyleBackColor = False
        '
        'Picplane
        '
        Me.Picplane.Image = Global.appairshow.My.Resources.Resources.plane
        Me.Picplane.Location = New System.Drawing.Point(783, 353)
        Me.Picplane.Name = "Picplane"
        Me.Picplane.Size = New System.Drawing.Size(140, 97)
        Me.Picplane.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.Picplane.TabIndex = 2
        Me.Picplane.TabStop = False
        Me.Picplane.UseWaitCursor = True
        '
        'Btngo
        '
        Me.Btngo.Location = New System.Drawing.Point(684, 509)
        Me.Btngo.Name = "Btngo"
        Me.Btngo.Size = New System.Drawing.Size(104, 28)
        Me.Btngo.TabIndex = 3
        Me.Btngo.Text = "fly"
        Me.Btngo.UseVisualStyleBackColor = True
        '
        'Pichella
        '
        Me.Pichella.Image = Global.appairshow.My.Resources.Resources.helicopterclipart
        Me.Pichella.Location = New System.Drawing.Point(26, 21)
        Me.Pichella.Name = "Pichella"
        Me.Pichella.Size = New System.Drawing.Size(127, 85)
        Me.Pichella.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.Pichella.TabIndex = 4
        Me.Pichella.TabStop = False
        '
        'Btnhover
        '
        Me.Btnhover.Location = New System.Drawing.Point(335, 527)
        Me.Btnhover.Name = "Btnhover"
        Me.Btnhover.Size = New System.Drawing.Size(222, 46)
        Me.Btnhover.TabIndex = 5
        Me.Btnhover.Text = "hover"
        Me.Btnhover.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(980, 666)
        Me.Controls.Add(Me.Btnhover)
        Me.Controls.Add(Me.Pichella)
        Me.Controls.Add(Me.Btngo)
        Me.Controls.Add(Me.Picplane)
        Me.Controls.Add(Me.Btnball)
        Me.Controls.Add(Me.Picballon)
        Me.Name = "Form1"
        Me.Text = "fly"
        CType(Me.Picballon, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Picplane, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Pichella, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Picballon As PictureBox
    Friend WithEvents Btnball As Button
    Friend WithEvents Picplane As PictureBox
    Friend WithEvents Btngo As Button
    Friend WithEvents Pichella As PictureBox
    Friend WithEvents Btnhover As Button
End Class
