﻿Public Class Form1
    Private Sub Btnball_Click(sender As Object, e As EventArgs) Handles Btnball.Click
        Dim d As Double
        Dim f As Double
        Dim h As Double
        Dim hella As Double

        For d = 0 To 600 Step 0.00001
            Picballon.Left = d
        Next

        For f = 600 To 0 Step -0.00001
            Picplane.Left = f

        Next


        For h = 0 To 400 Step 0.00001
            Pichella.Top = h
        Next

        For hella = 0 To 400 Step 0.00001
            Pichella.Top = hella
            Pichella.Left = hella
        Next

    End Sub
End Class

