﻿Public Class additon


    Private Sub btnplus_Click(sender As Object, e As EventArgs) Handles btnplus.Click
        'variables
        Dim intnumber1 As Integer = txtnumber1.Text
        Dim intnumber2 As Integer = txtnumber2.Text
        Dim intanswer As Integer

        intanswer = intnumber1 + intnumber2

        'MessageBox.Show(intanswer)

        lblresult.Text = intanswer.ToString




    End Sub

    Private Sub btnsubtract_Click(sender As Object, e As EventArgs) Handles btnsubtract.Click
        Dim intnumber1 As Integer = txtnumber1.Text
        Dim intnumber2 As Integer = txtnumber2.Text
        Dim intanswer As Integer

        intanswer = intnumber1 - intnumber2

        lblresult.Text = intanswer.ToString


    End Sub

    Private Sub btnmulti_Click(sender As Object, e As EventArgs) Handles btnmulti.Click
        Dim intnumber1 As Integer = txtnumber1.Text
        Dim intnumber2 As Integer = txtnumber2.Text
        Dim intanswer As Integer

        intanswer = intnumber1 * intnumber2

        lblresult.Text = intanswer.ToString

    End Sub

    Private Sub btndivde_Click(sender As Object, e As EventArgs) Handles btndivde.Click
        Dim intnumber1 As Integer = txtnumber1.Text
        Dim intnumber2 As Integer = txtnumber2.Text
        Dim intanswer As Double

        intanswer = intnumber1 / intnumber2

        lblresult.Text = intanswer.ToString

    End Sub
End Class
