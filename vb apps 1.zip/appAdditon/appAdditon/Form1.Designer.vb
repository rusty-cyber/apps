﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class additon
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnplus = New System.Windows.Forms.Button()
        Me.lblresult = New System.Windows.Forms.Label()
        Me.txtnumber1 = New System.Windows.Forms.TextBox()
        Me.txtnumber2 = New System.Windows.Forms.TextBox()
        Me.btnsubtract = New System.Windows.Forms.Button()
        Me.btnmulti = New System.Windows.Forms.Button()
        Me.btndivde = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'btnplus
        '
        Me.btnplus.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnplus.Font = New System.Drawing.Font("Microsoft Sans Serif", 21.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnplus.Location = New System.Drawing.Point(210, 173)
        Me.btnplus.Name = "btnplus"
        Me.btnplus.Size = New System.Drawing.Size(75, 53)
        Me.btnplus.TabIndex = 0
        Me.btnplus.Text = "+"
        Me.btnplus.UseVisualStyleBackColor = False
        '
        'lblresult
        '
        Me.lblresult.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblresult.Location = New System.Drawing.Point(169, 348)
        Me.lblresult.Name = "lblresult"
        Me.lblresult.Size = New System.Drawing.Size(480, 55)
        Me.lblresult.TabIndex = 1
        '
        'txtnumber1
        '
        Me.txtnumber1.Location = New System.Drawing.Point(299, 92)
        Me.txtnumber1.Name = "txtnumber1"
        Me.txtnumber1.Size = New System.Drawing.Size(166, 20)
        Me.txtnumber1.TabIndex = 2
        '
        'txtnumber2
        '
        Me.txtnumber2.Location = New System.Drawing.Point(299, 281)
        Me.txtnumber2.Name = "txtnumber2"
        Me.txtnumber2.Size = New System.Drawing.Size(166, 20)
        Me.txtnumber2.TabIndex = 3
        '
        'btnsubtract
        '
        Me.btnsubtract.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnsubtract.Location = New System.Drawing.Point(299, 173)
        Me.btnsubtract.Name = "btnsubtract"
        Me.btnsubtract.Size = New System.Drawing.Size(86, 53)
        Me.btnsubtract.TabIndex = 4
        Me.btnsubtract.Text = "-"
        Me.btnsubtract.UseVisualStyleBackColor = True
        '
        'btnmulti
        '
        Me.btnmulti.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnmulti.Location = New System.Drawing.Point(405, 173)
        Me.btnmulti.Name = "btnmulti"
        Me.btnmulti.Size = New System.Drawing.Size(60, 53)
        Me.btnmulti.TabIndex = 5
        Me.btnmulti.Text = "*"
        Me.btnmulti.UseVisualStyleBackColor = True
        '
        'btndivde
        '
        Me.btndivde.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btndivde.Location = New System.Drawing.Point(489, 173)
        Me.btndivde.Name = "btndivde"
        Me.btndivde.Size = New System.Drawing.Size(85, 53)
        Me.btndivde.TabIndex = 6
        Me.btndivde.Text = "/"
        Me.btndivde.UseVisualStyleBackColor = True
        '
        'additon
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.btndivde)
        Me.Controls.Add(Me.btnmulti)
        Me.Controls.Add(Me.btnsubtract)
        Me.Controls.Add(Me.txtnumber2)
        Me.Controls.Add(Me.txtnumber1)
        Me.Controls.Add(Me.lblresult)
        Me.Controls.Add(Me.btnplus)
        Me.Name = "additon"
        Me.Text = "additon"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnplus As Button
    Friend WithEvents lblresult As Label
    Friend WithEvents txtnumber1 As TextBox
    Friend WithEvents txtnumber2 As TextBox
    Friend WithEvents btnsubtract As Button
    Friend WithEvents btnmulti As Button
    Friend WithEvents btndivde As Button
End Class
