﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnRed = New System.Windows.Forms.Button()
        Me.lbcolourlabel = New System.Windows.Forms.Label()
        Me.BtnBlue = New System.Windows.Forms.Button()
        Me.BtnGreen = New System.Windows.Forms.Button()
        Me.btncreate = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'btnRed
        '
        Me.btnRed.BackColor = System.Drawing.SystemColors.Highlight
        Me.btnRed.Font = New System.Drawing.Font("Gill Sans Ultra Bold", 12.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnRed.ForeColor = System.Drawing.Color.Red
        Me.btnRed.Location = New System.Drawing.Point(345, 236)
        Me.btnRed.Name = "btnRed"
        Me.btnRed.Size = New System.Drawing.Size(106, 44)
        Me.btnRed.TabIndex = 0
        Me.btnRed.Text = "RED"
        Me.btnRed.UseVisualStyleBackColor = False
        '
        'lbcolourlabel
        '
        Me.lbcolourlabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lbcolourlabel.Location = New System.Drawing.Point(315, 143)
        Me.lbcolourlabel.Name = "lbcolourlabel"
        Me.lbcolourlabel.Size = New System.Drawing.Size(159, 68)
        Me.lbcolourlabel.TabIndex = 1
        '
        'BtnBlue
        '
        Me.BtnBlue.BackColor = System.Drawing.Color.Red
        Me.BtnBlue.ForeColor = System.Drawing.Color.Aqua
        Me.BtnBlue.Location = New System.Drawing.Point(98, 236)
        Me.BtnBlue.Name = "BtnBlue"
        Me.BtnBlue.Size = New System.Drawing.Size(85, 44)
        Me.BtnBlue.TabIndex = 2
        Me.BtnBlue.Text = "BLUE"
        Me.BtnBlue.UseVisualStyleBackColor = False
        '
        'BtnGreen
        '
        Me.BtnGreen.BackColor = System.Drawing.Color.Yellow
        Me.BtnGreen.ForeColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.BtnGreen.Location = New System.Drawing.Point(626, 236)
        Me.BtnGreen.Name = "BtnGreen"
        Me.BtnGreen.Size = New System.Drawing.Size(79, 44)
        Me.BtnGreen.TabIndex = 3
        Me.BtnGreen.Text = "GREEN"
        Me.BtnGreen.UseVisualStyleBackColor = False
        '
        'btncreate
        '
        Me.btncreate.Location = New System.Drawing.Point(345, 354)
        Me.btncreate.Name = "btncreate"
        Me.btncreate.Size = New System.Drawing.Size(106, 41)
        Me.btncreate.TabIndex = 4
        Me.btncreate.Text = "create an instnant "
        Me.btncreate.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Lime
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.btncreate)
        Me.Controls.Add(Me.BtnGreen)
        Me.Controls.Add(Me.BtnBlue)
        Me.Controls.Add(Me.lbcolourlabel)
        Me.Controls.Add(Me.btnRed)
        Me.Name = "Form1"
        Me.Text = "my project "
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents btnRed As Button
    Friend WithEvents lbcolourlabel As Label
    Friend WithEvents BtnBlue As Button
    Friend WithEvents BtnGreen As Button
    Friend WithEvents btncreate As Button
End Class
