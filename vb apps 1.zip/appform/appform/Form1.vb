﻿Public Class Form1
    Private Sub btnRed_Click(sender As Object, e As EventArgs) Handles btnRed.Click
        lbcolourlabel.BackColor = Color.Red

    End Sub

    Private Sub BtnBlue_Click(sender As Object, e As EventArgs) Handles BtnBlue.Click
        lbcolourlabel.BackColor = Color.Blue
    End Sub

    Private Sub BtnGreen_Click(sender As Object, e As EventArgs) Handles BtnGreen.Click
        lbcolourlabel.BackColor = Color.Green
    End Sub
End Class
