﻿Public Class Form1
    Private Sub Btnok_Click(sender As Object, e As EventArgs) Handles Btnok.Click
        Dim strvar As String
        strvar = Cbochoice.Text


        'adding item
        Cbochoice.Items.Add(Txtboxok.Text)


        Select Case strvar
            Case "item1"
                MessageBox.Show("this is a good choice")

            Case "item2"
                MessageBox.Show("this is item2 are u sure")

            Case "item3"
                MessageBox.Show("try again")

            Case "item4"
                MessageBox.Show("not for u")

            Case "item5"
                MessageBox.Show("try again")

            Case Else
                MessageBox.Show("please pick an item")
        End Select
    End Sub
End Class
