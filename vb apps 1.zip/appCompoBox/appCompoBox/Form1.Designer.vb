﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Cbochoice = New System.Windows.Forms.ComboBox()
        Me.Btnok = New System.Windows.Forms.Button()
        Me.Txtboxok = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'Cbochoice
        '
        Me.Cbochoice.FormattingEnabled = True
        Me.Cbochoice.Items.AddRange(New Object() {"item1", "item2", "item3", "item4", "item5"})
        Me.Cbochoice.Location = New System.Drawing.Point(220, 118)
        Me.Cbochoice.Name = "Cbochoice"
        Me.Cbochoice.Size = New System.Drawing.Size(121, 21)
        Me.Cbochoice.TabIndex = 0
        '
        'Btnok
        '
        Me.Btnok.Location = New System.Drawing.Point(207, 238)
        Me.Btnok.Name = "Btnok"
        Me.Btnok.Size = New System.Drawing.Size(225, 113)
        Me.Btnok.TabIndex = 1
        Me.Btnok.Text = "ok"
        Me.Btnok.UseVisualStyleBackColor = True
        '
        'Txtboxok
        '
        Me.Txtboxok.Location = New System.Drawing.Point(196, 31)
        Me.Txtboxok.Name = "Txtboxok"
        Me.Txtboxok.Size = New System.Drawing.Size(67, 20)
        Me.Txtboxok.TabIndex = 2
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.Txtboxok)
        Me.Controls.Add(Me.Btnok)
        Me.Controls.Add(Me.Cbochoice)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Cbochoice As ComboBox
    Friend WithEvents Btnok As Button
    Friend WithEvents Txtboxok As TextBox
End Class
