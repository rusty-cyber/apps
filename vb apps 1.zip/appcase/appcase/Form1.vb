﻿Public Class Form1
    Private Sub Btnok_Click(sender As Object, e As EventArgs) Handles Btnok.Click
        Dim intage As Integer
        intage = Val(Txtage.Text)

        Select Case intage
            Case 0 To 12
                MessageBox.Show("child")
            Case 13 To 19
                MessageBox.Show("teenager")
            Case 20 To 29
                MessageBox.Show("in your twenties")
            Case 30 To 39
                MessageBox.Show("in your thirties")
            Case Else
                MessageBox.Show("over 40")
        End Select
    End Sub
End Class
