﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Btnok = New System.Windows.Forms.Button()
        Me.Txtage = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'Btnok
        '
        Me.Btnok.Location = New System.Drawing.Point(290, 238)
        Me.Btnok.Name = "Btnok"
        Me.Btnok.Size = New System.Drawing.Size(169, 86)
        Me.Btnok.TabIndex = 0
        Me.Btnok.Text = "ok"
        Me.Btnok.UseVisualStyleBackColor = True
        '
        'Txtage
        '
        Me.Txtage.Location = New System.Drawing.Point(208, 82)
        Me.Txtage.Name = "Txtage"
        Me.Txtage.Size = New System.Drawing.Size(392, 20)
        Me.Txtage.TabIndex = 1
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.Txtage)
        Me.Controls.Add(Me.Btnok)
        Me.Name = "Form1"
        Me.Text = "select case"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Btnok As Button
    Friend WithEvents Txtage As TextBox
End Class
