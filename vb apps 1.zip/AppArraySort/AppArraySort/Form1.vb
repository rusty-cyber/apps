﻿Public Class Form1
    Private Sub Btnshort_Click(sender As Object, e As EventArgs) Handles Btnshort.Click

        Dim intnumbers() As Integer = {5, 3, 4, 11, 12}
        Dim intswap As Integer

        'If intnumbers(0) > intnumbers(1) Then
        '    intswap = intnumbers(0)
        '    intnumbers(0) = intnumbers(1)
        '    intnumbers(1) = intswap
        'End If
        'If intnumbers(1) > intnumbers(2) Then
        '    intswap = intnumbers(1)
        '    intnumbers(1) = intnumbers(2)
        '    intnumbers(2) = intswap
        'End If
        'If intnumbers(0) > intnumbers(1) Then
        '    intswap = intnumbers(0)
        '    intnumbers(0) = intnumbers(1)
        '    intnumbers(1) = intswap


        'End If

        Dim i. j 

For i = intnumbers.GetLowerBound(0) To intnumbers.GetUpperBound(0) - 1
            For j = intnumbers.GetLowerBound(0) To intnumbers.GetUpperBound(0) – 1
		If intnumbers(j) > intnumbers(j + 1) Then
                    intswap = intnumbers(j)
                    intnumbers(j) = intnumbers(j + 1)
                    intnumbers(j + 1) = intswap
                End If
            Next j
        Next i






        For i = intnumbers.GetLowerBound(0) To intnumbers.GetUpperBound(0)

            Lstdisplay.Items.Add(intnumbers(i))
        Next








    End Sub
End Class
