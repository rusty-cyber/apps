﻿Public Class Form1
    Private Sub Btnresult_Click(sender As Object, e As EventArgs) Handles Btnresult.Click
        Dim StrpassengerName As String ' passengers name '
        Dim StrpassengerAge As Integer ' passengers age'

        StrpassengerName = txtname.Text
        StrpassengerAge = Val(txtage.Text)

        If StrpassengerAge <= 12 Or StrpassengerAge >= 65 Then
            MessageBox.Show(StrpassengerName & "we have a discount for u")
        Else
            MessageBox.Show(StrpassengerName & "no discont")
        End If





    End Sub
End Class
