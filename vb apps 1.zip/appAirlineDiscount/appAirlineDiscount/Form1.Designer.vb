﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblname = New System.Windows.Forms.Label()
        Me.lblage = New System.Windows.Forms.Label()
        Me.txtname = New System.Windows.Forms.TextBox()
        Me.txtage = New System.Windows.Forms.TextBox()
        Me.Btnresult = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'lblname
        '
        Me.lblname.AutoSize = True
        Me.lblname.Location = New System.Drawing.Point(98, 43)
        Me.lblname.Name = "lblname"
        Me.lblname.Size = New System.Drawing.Size(33, 13)
        Me.lblname.TabIndex = 0
        Me.lblname.Text = "name"
        '
        'lblage
        '
        Me.lblage.AutoSize = True
        Me.lblage.Location = New System.Drawing.Point(104, 110)
        Me.lblage.Name = "lblage"
        Me.lblage.Size = New System.Drawing.Size(25, 13)
        Me.lblage.TabIndex = 1
        Me.lblage.Text = "age"
        '
        'txtname
        '
        Me.txtname.Location = New System.Drawing.Point(189, 40)
        Me.txtname.Name = "txtname"
        Me.txtname.Size = New System.Drawing.Size(109, 20)
        Me.txtname.TabIndex = 2
        '
        'txtage
        '
        Me.txtage.Location = New System.Drawing.Point(199, 107)
        Me.txtage.Name = "txtage"
        Me.txtage.Size = New System.Drawing.Size(52, 20)
        Me.txtage.TabIndex = 3
        '
        'Btnresult
        '
        Me.Btnresult.Location = New System.Drawing.Point(168, 224)
        Me.Btnresult.Name = "Btnresult"
        Me.Btnresult.Size = New System.Drawing.Size(69, 41)
        Me.Btnresult.TabIndex = 4
        Me.Btnresult.Text = "ok"
        Me.Btnresult.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Red
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.Btnresult)
        Me.Controls.Add(Me.txtage)
        Me.Controls.Add(Me.txtname)
        Me.Controls.Add(Me.lblage)
        Me.Controls.Add(Me.lblname)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblname As Label
    Friend WithEvents lblage As Label
    Friend WithEvents txtname As TextBox
    Friend WithEvents txtage As TextBox
    Friend WithEvents Btnresult As Button
End Class
