﻿Public Class frmMain

    'Declarations
    Dim dblNumerator As Double
    Dim dblDenominator As Double
    Dim dblQuotient As Double

    Private Sub btnDivide_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDivide.Click
        Try
            'Call Procedures

            Call Input()
            Call Processing()
            Call Output()
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try






    End Sub

    Private Sub Input()
        dblNumerator = txtNumerator.Text
        dblDenominator = txtDenominator.Text
    End Sub

    Private Sub Processing()
        dblQuotient = dblNumerator / dblDenominator
    End Sub

    Private Sub Output()
        lblQuotient.Text = dblQuotient.ToString
    End Sub

End Class
