﻿Public Class frmMain

    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        End
    End Sub

    Private Sub btnBalance_Click(ByVal sender As System.Object,
    ByVal e As System.EventArgs) Handles btnBalance.Click
        'Declarations
        Dim dblBeginningBalance As Double
        Dim dblEndingBalance As Double
        Dim dblDeposits As Double
        Dim dblWithdrawals As Double
        'Input
        dblBeginningBalance = txtBeginningBalance.Text
        dblDeposits = txtDeposits.Text
        dblWithdrawals = txtWithdrawals.Text
        'Processing
        dblEndingBalance = dblBeginningBalance + dblDeposits - dblWithdrawals
        'Output
        LblEndingBalance.Text = dblEndingBalance.ToString("c")

    End Sub

End Class
