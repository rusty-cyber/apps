﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.btnBalance = New System.Windows.Forms.Button()
        Me.txtDeposits = New System.Windows.Forms.TextBox()
        Me.txtBeginningBalance = New System.Windows.Forms.TextBox()
        Me.txtWithdrawals = New System.Windows.Forms.TextBox()
        Me.LblEndingBalance = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'btnExit
        '
        Me.btnExit.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnExit.Location = New System.Drawing.Point(253, 305)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(82, 35)
        Me.btnExit.TabIndex = 0
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'btnBalance
        '
        Me.btnBalance.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBalance.Location = New System.Drawing.Point(253, 185)
        Me.btnBalance.Name = "btnBalance"
        Me.btnBalance.Size = New System.Drawing.Size(81, 34)
        Me.btnBalance.TabIndex = 1
        Me.btnBalance.Text = "Balance"
        Me.btnBalance.UseVisualStyleBackColor = True
        '
        'txtDeposits
        '
        Me.txtDeposits.Location = New System.Drawing.Point(211, 85)
        Me.txtDeposits.Name = "txtDeposits"
        Me.txtDeposits.Size = New System.Drawing.Size(130, 20)
        Me.txtDeposits.TabIndex = 2
        '
        'txtBeginningBalance
        '
        Me.txtBeginningBalance.Location = New System.Drawing.Point(212, 39)
        Me.txtBeginningBalance.Name = "txtBeginningBalance"
        Me.txtBeginningBalance.Size = New System.Drawing.Size(129, 20)
        Me.txtBeginningBalance.TabIndex = 3
        '
        'txtWithdrawals
        '
        Me.txtWithdrawals.Location = New System.Drawing.Point(211, 129)
        Me.txtWithdrawals.Name = "txtWithdrawals"
        Me.txtWithdrawals.Size = New System.Drawing.Size(124, 20)
        Me.txtWithdrawals.TabIndex = 4
        '
        'LblEndingBalance
        '
        Me.LblEndingBalance.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.LblEndingBalance.ForeColor = System.Drawing.SystemColors.ControlText
        Me.LblEndingBalance.Location = New System.Drawing.Point(211, 243)
        Me.LblEndingBalance.Name = "LblEndingBalance"
        Me.LblEndingBalance.Size = New System.Drawing.Size(124, 28)
        Me.LblEndingBalance.TabIndex = 5
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(152, 88)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(48, 13)
        Me.Label1.TabIndex = 6
        Me.Label1.Text = "Deposits"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(104, 42)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(96, 13)
        Me.Label2.TabIndex = 7
        Me.Label2.Text = "Beginning Balance"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(135, 136)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(65, 13)
        Me.Label3.TabIndex = 8
        Me.Label3.Text = "Withdrawals"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(119, 258)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(81, 13)
        Me.Label4.TabIndex = 9
        Me.Label4.Text = "Ending balance"
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(347, 352)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.LblEndingBalance)
        Me.Controls.Add(Me.txtWithdrawals)
        Me.Controls.Add(Me.txtBeginningBalance)
        Me.Controls.Add(Me.txtDeposits)
        Me.Controls.Add(Me.btnBalance)
        Me.Controls.Add(Me.btnExit)
        Me.Name = "frmMain"
        Me.Text = "Debugging errors: accounts balances"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnExit As System.Windows.Forms.Button
    Friend WithEvents btnBalance As System.Windows.Forms.Button
    Friend WithEvents txtDeposits As System.Windows.Forms.TextBox
    Friend WithEvents txtBeginningBalance As System.Windows.Forms.TextBox
    Friend WithEvents txtWithdrawals As System.Windows.Forms.TextBox
    Friend WithEvents LblEndingBalance As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label

End Class
