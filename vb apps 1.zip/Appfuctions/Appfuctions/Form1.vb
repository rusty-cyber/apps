﻿Public Class Form1


    Private Sub btnfunction_Click(sender As Object, e As EventArgs) Handles btnfunction.Click
        Dim blnerror As Boolean
        blnerror = checkerrors()

        If blnerror = True Then
            MessageBox.Show("plese enter text in the text box ")
        Else
            MessageBox.Show("no error")
        End If
    End Sub

    Private Function checkerrors() As Boolean
        Dim strdate As String = txtfuncation.Text

        If strdate = "" Then
            MessageBox.Show("blank text box detected")
            Return True
        Else
            Return False

        End If

    End Function

    Private Function Addtwonumbers(intfirst As Integer, intsecond As Integer) As Integer
        Return intfirst + intsecond


    End Function

    Private Sub btnadd_Click(sender As Object, e As EventArgs) Handles btnadd.Click
        Dim intnum1 As Integer
        Dim intnum2 As Integer
        Dim intresult As Integer

        intnum1 = Val(txtfirst.Text)
        intnum2 = Val(Txtsecond.Text)

        intresult = Addtwonumbers(intnum1, intnum2)
        MessageBox.Show(intresult.ToString)
    End Sub
End Class
