﻿Public Class frmMain

    Private Sub btnOK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOK.Click
        Dim i As Integer
        Dim intLetterCount As Integer
        Dim strText As String
        Dim chrletter As Char

        strText = "Google".ToLower

        For i = 1 To strText.Length - 1
            chrletter = strText.Substring(i)

            If chrletter = "g" Then

                intLetterCount = intLetterCount + 1

            End If

        Next

        txtWord.Text = "G appears " & intLetterCount & " times"
    End Sub
End Class
