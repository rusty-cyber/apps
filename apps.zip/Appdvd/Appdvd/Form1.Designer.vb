﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Txtprice = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Btnok = New System.Windows.Forms.Button()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Lblresult = New System.Windows.Forms.Label()
        Me.Lblvat = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'Txtprice
        '
        Me.Txtprice.Location = New System.Drawing.Point(226, 38)
        Me.Txtprice.Name = "Txtprice"
        Me.Txtprice.Size = New System.Drawing.Size(265, 23)
        Me.Txtprice.TabIndex = 0
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(-124, -59)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(41, 15)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Label1"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(113, 43)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(33, 15)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "price"
        '
        'Btnok
        '
        Me.Btnok.Location = New System.Drawing.Point(279, 137)
        Me.Btnok.Name = "Btnok"
        Me.Btnok.Size = New System.Drawing.Size(118, 41)
        Me.Btnok.TabIndex = 3
        Me.Btnok.Text = "calculate"
        Me.Btnok.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(-86, 163)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(41, 15)
        Me.Label3.TabIndex = 5
        Me.Label3.Text = "Label3"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(163, 279)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(48, 15)
        Me.Label4.TabIndex = 6
        Me.Label4.Text = "vat 21%"
        '
        'Lblresult
        '
        Me.Lblresult.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Lblresult.Location = New System.Drawing.Point(199, 351)
        Me.Lblresult.Name = "Lblresult"
        Me.Lblresult.Size = New System.Drawing.Size(348, 63)
        Me.Lblresult.TabIndex = 7
        '
        'Lblvat
        '
        Me.Lblvat.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Lblvat.Location = New System.Drawing.Point(236, 277)
        Me.Lblvat.Name = "Lblvat"
        Me.Lblvat.Size = New System.Drawing.Size(242, 34)
        Me.Lblvat.TabIndex = 8
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.Lblvat)
        Me.Controls.Add(Me.Lblresult)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Btnok)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Txtprice)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Txtprice As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Btnok As Button
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Lblresult As Label
    Friend WithEvents Lblvat As Label
End Class
