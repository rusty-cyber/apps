﻿Public Class Form1
    Private Sub Btncalcu_Click(sender As Object, e As EventArgs) Handles Btncalcu.Click
        Dim dbldvdprice As Double
        Dim dblvat As Double
        Dim dblresult As Double

        dbldvdprice = Val(Txtprice.Text)

        dblvat = dbldvdprice * 0.21

        dblresult = dbldvdprice + dblvat

        Lblvat.Text = dblvat.ToString("c")

        Lblresult.Text = dblresult.ToString("c")



    End Sub

    Private Sub Btnend_Click(sender As Object, e As EventArgs) Handles Btnend.Click
        End
    End Sub
End Class
