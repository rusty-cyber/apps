﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Btncalcu = New System.Windows.Forms.Button()
        Me.Btnend = New System.Windows.Forms.Button()
        Me.Txtprice = New System.Windows.Forms.TextBox()
        Me.price = New System.Windows.Forms.Label()
        Me.Lblvat = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Lblresult = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'Btncalcu
        '
        Me.Btncalcu.Location = New System.Drawing.Point(258, 170)
        Me.Btncalcu.Name = "Btncalcu"
        Me.Btncalcu.Size = New System.Drawing.Size(205, 86)
        Me.Btncalcu.TabIndex = 0
        Me.Btncalcu.Text = "calculate"
        Me.Btncalcu.UseVisualStyleBackColor = True
        '
        'Btnend
        '
        Me.Btnend.Location = New System.Drawing.Point(601, 193)
        Me.Btnend.Name = "Btnend"
        Me.Btnend.Size = New System.Drawing.Size(111, 39)
        Me.Btnend.TabIndex = 1
        Me.Btnend.Text = "end"
        Me.Btnend.UseVisualStyleBackColor = True
        '
        'Txtprice
        '
        Me.Txtprice.Location = New System.Drawing.Point(277, 71)
        Me.Txtprice.Name = "Txtprice"
        Me.Txtprice.Size = New System.Drawing.Size(276, 20)
        Me.Txtprice.TabIndex = 2
        Me.Txtprice.Text = "3"
        '
        'price
        '
        Me.price.AutoSize = True
        Me.price.Location = New System.Drawing.Point(148, 70)
        Me.price.Name = "price"
        Me.price.Size = New System.Drawing.Size(30, 13)
        Me.price.TabIndex = 3
        Me.price.Text = "price"
        '
        'Lblvat
        '
        Me.Lblvat.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Lblvat.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Lblvat.ForeColor = System.Drawing.SystemColors.ActiveCaption
        Me.Lblvat.Location = New System.Drawing.Point(276, 313)
        Me.Lblvat.Name = "Lblvat"
        Me.Lblvat.Size = New System.Drawing.Size(116, 26)
        Me.Lblvat.TabIndex = 4
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(143, 322)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(45, 13)
        Me.Label1.TabIndex = 5
        Me.Label1.Text = "vat 21%"
        '
        'Lblresult
        '
        Me.Lblresult.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Lblresult.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Lblresult.Location = New System.Drawing.Point(271, 388)
        Me.Lblresult.Name = "Lblresult"
        Me.Lblresult.Size = New System.Drawing.Size(330, 50)
        Me.Lblresult.TabIndex = 6
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(98, 391)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(32, 13)
        Me.Label2.TabIndex = 7
        Me.Label2.Text = "result"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Lblresult)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Lblvat)
        Me.Controls.Add(Me.price)
        Me.Controls.Add(Me.Txtprice)
        Me.Controls.Add(Me.Btnend)
        Me.Controls.Add(Me.Btncalcu)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Btncalcu As Button
    Friend WithEvents Btnend As Button
    Friend WithEvents Txtprice As TextBox
    Friend WithEvents price As Label
    Friend WithEvents Lblvat As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Lblresult As Label
    Friend WithEvents Label2 As Label
End Class
