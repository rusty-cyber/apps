﻿Public Class Form1
    Private Sub btnrandom_Click(sender As Object, e As EventArgs) Handles btnrandom.Click
        'declare varilables
        Dim rndgenerator As Random
        Dim intvaule As Integer

        'generator a new object 
        rndgenerator = New Random

        ' get a value between 1 and 10 
        intvaule = rndgenerator.Next(1, 11)

        'display your value 
        lblrandom.Text = lblrandom.Text & " " & intvaule.ToString


    End Sub
End Class
