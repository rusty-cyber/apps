﻿Public Class convertedweight
    Private bdlweightconvert As Double

    Public Function getkg(dblweight As Double) As Double
        bdlweightconvert = dblweight / 2.2
        Return bdlweightconvert
    End Function

    Public Function getpons(dblweight As Double) As Double
        bdlweightconvert = dblweight * 2.2
        Return bdlweightconvert

    End Function


End Class
