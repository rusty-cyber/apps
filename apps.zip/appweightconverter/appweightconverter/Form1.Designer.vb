﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Rdkiliograms = New System.Windows.Forms.RadioButton()
        Me.Rdpounds = New System.Windows.Forms.RadioButton()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.lblweight = New System.Windows.Forms.Label()
        Me.Txtweight = New System.Windows.Forms.TextBox()
        Me.btnconvert = New System.Windows.Forms.Button()
        Me.Lblresult = New System.Windows.Forms.Label()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Rdkiliograms
        '
        Me.Rdkiliograms.AutoSize = True
        Me.Rdkiliograms.Location = New System.Drawing.Point(19, 19)
        Me.Rdkiliograms.Name = "Rdkiliograms"
        Me.Rdkiliograms.Size = New System.Drawing.Size(58, 17)
        Me.Rdkiliograms.TabIndex = 0
        Me.Rdkiliograms.TabStop = True
        Me.Rdkiliograms.Text = "to kilos"
        Me.Rdkiliograms.UseVisualStyleBackColor = True
        '
        'Rdpounds
        '
        Me.Rdpounds.AutoSize = True
        Me.Rdpounds.Location = New System.Drawing.Point(19, 69)
        Me.Rdpounds.Name = "Rdpounds"
        Me.Rdpounds.Size = New System.Drawing.Size(75, 17)
        Me.Rdpounds.TabIndex = 1
        Me.Rdpounds.TabStop = True
        Me.Rdpounds.Text = "to pounds "
        Me.Rdpounds.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Rdpounds)
        Me.GroupBox1.Controls.Add(Me.Rdkiliograms)
        Me.GroupBox1.Location = New System.Drawing.Point(284, 143)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(128, 123)
        Me.GroupBox1.TabIndex = 2
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "select converter "
        '
        'lblweight
        '
        Me.lblweight.Location = New System.Drawing.Point(185, 62)
        Me.lblweight.Name = "lblweight"
        Me.lblweight.Size = New System.Drawing.Size(93, 20)
        Me.lblweight.TabIndex = 3
        Me.lblweight.Text = "enter weight "
        '
        'Txtweight
        '
        Me.Txtweight.Location = New System.Drawing.Point(284, 62)
        Me.Txtweight.Name = "Txtweight"
        Me.Txtweight.Size = New System.Drawing.Size(145, 20)
        Me.Txtweight.TabIndex = 6
        '
        'btnconvert
        '
        Me.btnconvert.Location = New System.Drawing.Point(303, 290)
        Me.btnconvert.Name = "btnconvert"
        Me.btnconvert.Size = New System.Drawing.Size(99, 25)
        Me.btnconvert.TabIndex = 7
        Me.btnconvert.Text = "comvert"
        Me.btnconvert.UseVisualStyleBackColor = True
        '
        'Lblresult
        '
        Me.Lblresult.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Lblresult.Location = New System.Drawing.Point(283, 364)
        Me.Lblresult.Name = "Lblresult"
        Me.Lblresult.Size = New System.Drawing.Size(161, 53)
        Me.Lblresult.TabIndex = 8
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Lime
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.Lblresult)
        Me.Controls.Add(Me.btnconvert)
        Me.Controls.Add(Me.Txtweight)
        Me.Controls.Add(Me.lblweight)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Rdkiliograms As RadioButton
    Friend WithEvents Rdpounds As RadioButton
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents lblweight As Label
    Friend WithEvents Txtweight As TextBox
    Friend WithEvents btnconvert As Button
    Friend WithEvents Lblresult As Label
End Class
