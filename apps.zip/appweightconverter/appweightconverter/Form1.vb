﻿Public Class Form1
    Private Sub btnconvert_Click(sender As Object, e As EventArgs) Handles btnconvert.Click
        Dim dblweight As Double
        Dim dblconvertedweight As Double
        Dim objconvertedweight As New convertedweight

        dblweight = Val(Txtweight.Text)
        If Rdkiliograms.Checked Then
            dblconvertedweight = objconvertedweight.getkg(dblweight)

        ElseIf Rdpounds.Checked Then
            dblconvertedweight = objconvertedweight.getpons(dblweight)



        End If

        Lblresult.Text = dblconvertedweight.ToString






    End Sub
End Class
