﻿Public Class Form1
    Private Sub btnrolldie_Click(sender As Object, e As EventArgs) Handles btnrolldie.Click
        Dim rndDice As Random
        Dim intvalue As Integer

        rndDice = New Random

        intvalue = rndDice.Next(1, 7)


        picdievalue.Image = ImageList1.Images("die.jpg")
        'MessageBox.Show(intvalue)

        picdievalue.Image = ImageList1.Images(intvalue - 1)

        'elect Case picdievalue
        'Case 1
        'picdievalue.Image = ImageList1.Images("die.jpg")
        'e 2
        'picdievalue.Image = ImageList1.Images("die.jpg")
        'Case 3
        'dievalue.Image = ImageList1.Images("die.jpg")
        'Case 4
        'picdievalue.Image = ImageList1.Images("die.jpg")
        'Case 5
        '        picdievalue.Image = ImageList1.Images("die.jpg")
        '    Case 6
        '        picdievalue.Image = ImageList1.Images("die.jpg")

        'End Select


    End Sub
End Class
