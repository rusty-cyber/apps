﻿Public Class tempconverter

    Dim intnewtep As Integer
    Public Function getfahr(inttemp As Integer) As Integer

        intnewtep = 9 * (inttemp / 5) + 32
        Return intnewtep

    End Function

    Public Function getcelsuius(inttemp As Integer) As Integer

        intnewtep = 5 * (inttemp - 32) / 9
        Return intnewtep
    End Function
End Class
