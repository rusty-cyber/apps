﻿Public Class Form1
    Private Sub btnconvert_Click(sender As Object, e As EventArgs) Handles btnconvert.Click
        Dim inttemp As Integer
        Dim intconverttemp As Integer
        Dim objconvert As New tempconverter ' making an object

        inttemp = Val(txttemprature.Text)

        If Rdcelusus.Checked Then
            intconverttemp = objconvert.getfahr(inttemp)
        ElseIf intconverttemp = objconvert.getcelsuius(inttemp)
        End If
        intconverttemp = objconvert.getfahr(inttemp)



        Lblnewtemp.Text = intconverttemp.ToString
    End Sub




End Class
