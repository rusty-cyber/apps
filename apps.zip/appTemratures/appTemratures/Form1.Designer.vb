﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txttemprature = New System.Windows.Forms.TextBox()
        Me.btnconvert = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Lblnewtemp = New System.Windows.Forms.Label()
        Me.Rdcelusus = New System.Windows.Forms.RadioButton()
        Me.Rdferonhight = New System.Windows.Forms.RadioButton()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label1.Location = New System.Drawing.Point(97, 60)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(91, 27)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "enter temprature"
        '
        'txttemprature
        '
        Me.txttemprature.Location = New System.Drawing.Point(293, 62)
        Me.txttemprature.Name = "txttemprature"
        Me.txttemprature.Size = New System.Drawing.Size(245, 20)
        Me.txttemprature.TabIndex = 1
        '
        'btnconvert
        '
        Me.btnconvert.Location = New System.Drawing.Point(335, 245)
        Me.btnconvert.Name = "btnconvert"
        Me.btnconvert.Size = New System.Drawing.Size(158, 51)
        Me.btnconvert.TabIndex = 2
        Me.btnconvert.Text = "convert "
        Me.btnconvert.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label2.Location = New System.Drawing.Point(81, 344)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(134, 21)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "converted temprature"
        '
        'Lblnewtemp
        '
        Me.Lblnewtemp.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Lblnewtemp.Location = New System.Drawing.Point(253, 341)
        Me.Lblnewtemp.Name = "Lblnewtemp"
        Me.Lblnewtemp.Size = New System.Drawing.Size(342, 45)
        Me.Lblnewtemp.TabIndex = 4
        '
        'Rdcelusus
        '
        Me.Rdcelusus.AutoSize = True
        Me.Rdcelusus.Location = New System.Drawing.Point(74, 9)
        Me.Rdcelusus.Name = "Rdcelusus"
        Me.Rdcelusus.Size = New System.Drawing.Size(55, 17)
        Me.Rdcelusus.TabIndex = 5
        Me.Rdcelusus.TabStop = True
        Me.Rdcelusus.Text = "celsus"
        Me.Rdcelusus.UseVisualStyleBackColor = True
        '
        'Rdferonhight
        '
        Me.Rdferonhight.AutoSize = True
        Me.Rdferonhight.Location = New System.Drawing.Point(74, 65)
        Me.Rdferonhight.Name = "Rdferonhight"
        Me.Rdferonhight.Size = New System.Drawing.Size(76, 17)
        Me.Rdferonhight.TabIndex = 6
        Me.Rdferonhight.TabStop = True
        Me.Rdferonhight.Text = "feronheart "
        Me.Rdferonhight.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Rdferonhight)
        Me.GroupBox1.Controls.Add(Me.Rdcelusus)
        Me.GroupBox1.Location = New System.Drawing.Point(377, 118)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(217, 106)
        Me.GroupBox1.TabIndex = 7
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "pick one "
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.Lblnewtemp)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.btnconvert)
        Me.Controls.Add(Me.txttemprature)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents txttemprature As TextBox
    Friend WithEvents btnconvert As Button
    Friend WithEvents Label2 As Label
    Friend WithEvents Lblnewtemp As Label
    Friend WithEvents Rdcelusus As RadioButton
    Friend WithEvents Rdferonhight As RadioButton
    Friend WithEvents GroupBox1 As GroupBox
End Class
