﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnresult = New System.Windows.Forms.Button()
        Me.Piccoin2 = New System.Windows.Forms.PictureBox()
        Me.Piccoin1 = New System.Windows.Forms.PictureBox()
        CType(Me.Piccoin2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Piccoin1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnresult
        '
        Me.btnresult.Location = New System.Drawing.Point(290, 218)
        Me.btnresult.Name = "btnresult"
        Me.btnresult.Size = New System.Drawing.Size(200, 103)
        Me.btnresult.TabIndex = 0
        Me.btnresult.Text = "toss a coin"
        Me.btnresult.UseVisualStyleBackColor = True
        '
        'Piccoin2
        '
        Me.Piccoin2.Image = Global.apptosscoin.My.Resources.Resources.Coin2
        Me.Piccoin2.Location = New System.Drawing.Point(251, 2)
        Me.Piccoin2.Name = "Piccoin2"
        Me.Piccoin2.Size = New System.Drawing.Size(295, 210)
        Me.Piccoin2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.Piccoin2.TabIndex = 2
        Me.Piccoin2.TabStop = False
        Me.Piccoin2.Visible = False
        '
        'Piccoin1
        '
        Me.Piccoin1.Image = Global.apptosscoin.My.Resources.Resources.Coin1
        Me.Piccoin1.Location = New System.Drawing.Point(219, 42)
        Me.Piccoin1.Name = "Piccoin1"
        Me.Piccoin1.Size = New System.Drawing.Size(352, 170)
        Me.Piccoin1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.Piccoin1.TabIndex = 1
        Me.Piccoin1.TabStop = False
        Me.Piccoin1.Visible = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.Piccoin2)
        Me.Controls.Add(Me.Piccoin1)
        Me.Controls.Add(Me.btnresult)
        Me.Name = "Form1"
        Me.Text = "Form1"
        CType(Me.Piccoin2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Piccoin1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents btnresult As Button
    Friend WithEvents Piccoin1 As PictureBox
    Friend WithEvents Piccoin2 As PictureBox
End Class
