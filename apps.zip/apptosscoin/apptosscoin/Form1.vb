﻿Public Class Form1


    Private Sub btnresult_Click(sender As Object, e As EventArgs) Handles btnresult.Click
        Dim rndgenerator As Random
        Dim intvalue As Integer

        'generate
        rndgenerator = New Random

        'get new vaule 
        intvalue = rndgenerator.Next(1, 3)

        'MessageBox.Show(intvalue.ToString)

        'display the coin
        If intvalue = 1 Then
            Piccoin1.Visible = True
            Piccoin2.Visible = False

        Else
            Piccoin1.Visible = False
            Piccoin2.Visible = True

        End If
    End Sub
End Class
