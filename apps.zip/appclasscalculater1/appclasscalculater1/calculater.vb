﻿Public Class calculater
    Shared Function add(int1 As Integer, int2 As Integer) As Integer
        Dim intanswer As Integer
        Return intanswer
    End Function


    Shared Function subtract(int1 As Integer, int2 As Integer) As Integer
        Dim intanswer As Integer
        Return intanswer
    End Function


    Shared Function multiply(int1 As Integer, int2 As Integer) As Integer
        Dim intanswer As Integer
        Return intanswer
    End Function


    Shared Function divide(int1 As Integer, int2 As Integer) As Integer
        Dim intanswer As Double
        Return intanswer
    End Function
End Class
