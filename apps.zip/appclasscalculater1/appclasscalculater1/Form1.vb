﻿Public Class Form1


    Private Sub btnplus_Click(sender As Object, e As EventArgs) Handles btnplus.Click
        Dim intnum1 As Integer = Val(txtnum1.Text)
        Dim intnum2 As Integer = Val(txtnum2.Text)
        Dim intresult As Integer

        intresult = calculater.add(intnum1, intnum2)

        lblresult.Text = intresult.ToString

    End Sub

    Private Sub btnminus_Click(sender As Object, e As EventArgs) Handles btnminus.Click
        Dim intnum1 As Integer = Val(txtnum1.Text)
        Dim intnum2 As Integer = Val(txtnum2.Text)
        Dim intresult As Integer

        intresult = calculater.subtract(intnum1, intnum2)

        lblresult.Text = intresult.ToString


    End Sub

    Private Sub btnmultiply_Click(sender As Object, e As EventArgs) Handles btnmultiply.Click
        Dim intnum1 As Integer = Val(txtnum1.Text)
        Dim intnum2 As Integer = Val(txtnum2.Text)
        Dim intresult As Integer

        intresult = calculater.multiply(intnum1, intnum2)

        lblresult.Text = intresult.ToString


    End Sub

    Private Sub btndivide_Click(sender As Object, e As EventArgs) Handles btndivide.Click
        Dim intnum1 As Integer = Val(txtnum1.Text)
        Dim intnum2 As Integer = Val(txtnum2.Text)
        Dim intresult As Double

        intresult = calculater.divide(intnum1, intnum2)

        lblresult.Text = intresult.ToString

    End Sub
End Class
