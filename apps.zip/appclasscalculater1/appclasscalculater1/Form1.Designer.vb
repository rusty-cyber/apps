﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.txtnum1 = New System.Windows.Forms.TextBox()
        Me.txtnum2 = New System.Windows.Forms.TextBox()
        Me.btnplus = New System.Windows.Forms.Button()
        Me.lblresult = New System.Windows.Forms.Label()
        Me.btnminus = New System.Windows.Forms.Button()
        Me.btnmultiply = New System.Windows.Forms.Button()
        Me.btndivide = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'txtnum1
        '
        Me.txtnum1.Location = New System.Drawing.Point(287, 29)
        Me.txtnum1.Name = "txtnum1"
        Me.txtnum1.Size = New System.Drawing.Size(91, 20)
        Me.txtnum1.TabIndex = 0
        '
        'txtnum2
        '
        Me.txtnum2.Location = New System.Drawing.Point(293, 79)
        Me.txtnum2.Name = "txtnum2"
        Me.txtnum2.Size = New System.Drawing.Size(84, 20)
        Me.txtnum2.TabIndex = 1
        '
        'btnplus
        '
        Me.btnplus.Location = New System.Drawing.Point(200, 157)
        Me.btnplus.Name = "btnplus"
        Me.btnplus.Size = New System.Drawing.Size(54, 41)
        Me.btnplus.TabIndex = 2
        Me.btnplus.Text = "+"
        Me.btnplus.UseVisualStyleBackColor = True
        '
        'lblresult
        '
        Me.lblresult.AccessibleRole = System.Windows.Forms.AccessibleRole.None
        Me.lblresult.AutoSize = True
        Me.lblresult.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblresult.Enabled = False
        Me.lblresult.Location = New System.Drawing.Point(328, 259)
        Me.lblresult.Name = "lblresult"
        Me.lblresult.Size = New System.Drawing.Size(2, 15)
        Me.lblresult.TabIndex = 3
        '
        'btnminus
        '
        Me.btnminus.Location = New System.Drawing.Point(328, 157)
        Me.btnminus.Name = "btnminus"
        Me.btnminus.Size = New System.Drawing.Size(52, 33)
        Me.btnminus.TabIndex = 4
        Me.btnminus.Text = "-"
        Me.btnminus.UseVisualStyleBackColor = True
        '
        'btnmultiply
        '
        Me.btnmultiply.Location = New System.Drawing.Point(441, 160)
        Me.btnmultiply.Name = "btnmultiply"
        Me.btnmultiply.Size = New System.Drawing.Size(41, 37)
        Me.btnmultiply.TabIndex = 5
        Me.btnmultiply.Text = "*"
        Me.btnmultiply.UseVisualStyleBackColor = True
        '
        'btndivide
        '
        Me.btndivide.Location = New System.Drawing.Point(539, 154)
        Me.btndivide.Name = "btndivide"
        Me.btndivide.Size = New System.Drawing.Size(49, 42)
        Me.btndivide.TabIndex = 6
        Me.btndivide.Text = "/"
        Me.btndivide.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.btndivide)
        Me.Controls.Add(Me.btnmultiply)
        Me.Controls.Add(Me.btnminus)
        Me.Controls.Add(Me.lblresult)
        Me.Controls.Add(Me.btnplus)
        Me.Controls.Add(Me.txtnum2)
        Me.Controls.Add(Me.txtnum1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents txtnum1 As TextBox
    Friend WithEvents txtnum2 As TextBox
    Friend WithEvents btnplus As Button
    Friend WithEvents lblresult As Label
    Friend WithEvents btnminus As Button
    Friend WithEvents btnmultiply As Button
    Friend WithEvents btndivide As Button
End Class
