﻿Public Class arrays
    Private Sub Btnintarray_Click(sender As Object, e As EventArgs) Handles Btnintarray.Click
        Dim intnumber(5) As Integer

        intnumber(0) = 10
        intnumber(1) = 20
        intnumber(2) = 30
        intnumber(3) = 40
        intnumber(4) = 50
        intnumber(5) = 60

        'MessageBox.Show("first number is " & intnumber(0))
        'MessageBox.Show("first number is " & intnumber(1))
        'MessageBox.Show("first number is " & intnumber(2))
        'MessageBox.Show("first number is " & intnumber(3))
        'MessageBox.Show("first number is " & intnumber(4))
        'MessageBox.Show("first number is " & intnumber(5))

        For i = 0 To 5

            Lstbox.Items.Add(intnumber(i))
        Next
    End Sub

    Private Sub Btnstrarray_Click(sender As Object, e As EventArgs) Handles Btnstrarray.Click
        Dim strtext(4) As String
        strtext(0) = "this"
        strtext(1) = "is"
        strtext(2) = "a"
        strtext(3) = "string"
        strtext(4) = "array"

        For s = 0 To 4
            Lstbox.Items.Add(strtext(s))
        Next


    End Sub

    Private Sub Btntables_Click(sender As Object, e As EventArgs) Handles Btntables.Click
        Dim intnumber(10) As Integer

        For t = 0 To 10
            intnumber(t) = 1 * 7
            Lstbox.Items.Add("7 times" & t & " = " & intnumber(t))
        Next
    End Sub
End Class