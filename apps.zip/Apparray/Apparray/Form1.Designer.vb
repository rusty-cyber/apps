﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class arrays
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Btnintarray = New System.Windows.Forms.Button()
        Me.Lstbox = New System.Windows.Forms.ListBox()
        Me.Btnstrarray = New System.Windows.Forms.Button()
        Me.Btntables = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Btnintarray
        '
        Me.Btnintarray.Location = New System.Drawing.Point(96, 213)
        Me.Btnintarray.Name = "Btnintarray"
        Me.Btnintarray.Size = New System.Drawing.Size(157, 85)
        Me.Btnintarray.TabIndex = 0
        Me.Btnintarray.Text = "array"
        Me.Btnintarray.UseVisualStyleBackColor = True
        '
        'Lstbox
        '
        Me.Lstbox.FormattingEnabled = True
        Me.Lstbox.Location = New System.Drawing.Point(224, 81)
        Me.Lstbox.Name = "Lstbox"
        Me.Lstbox.Size = New System.Drawing.Size(327, 108)
        Me.Lstbox.TabIndex = 1
        '
        'Btnstrarray
        '
        Me.Btnstrarray.Location = New System.Drawing.Point(323, 213)
        Me.Btnstrarray.Name = "Btnstrarray"
        Me.Btnstrarray.Size = New System.Drawing.Size(182, 85)
        Me.Btnstrarray.TabIndex = 2
        Me.Btnstrarray.Text = "string"
        Me.Btnstrarray.UseVisualStyleBackColor = True
        '
        'Btntables
        '
        Me.Btntables.Location = New System.Drawing.Point(578, 235)
        Me.Btntables.Name = "Btntables"
        Me.Btntables.Size = New System.Drawing.Size(132, 62)
        Me.Btntables.TabIndex = 3
        Me.Btntables.Text = "tables"
        Me.Btntables.UseVisualStyleBackColor = True
        '
        'arrays
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.Btntables)
        Me.Controls.Add(Me.Btnstrarray)
        Me.Controls.Add(Me.Lstbox)
        Me.Controls.Add(Me.Btnintarray)
        Me.Name = "arrays"
        Me.Text = "arrays"
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Btnintarray As Button
    Friend WithEvents Lstbox As ListBox
    Friend WithEvents Btnstrarray As Button
    Friend WithEvents Btntables As Button
End Class
