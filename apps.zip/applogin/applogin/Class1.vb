﻿Public Class userlogin



    Private user As String = "Admin"

    Private pass As String = "password"


    Public Function login(struser As String, strpass As String) As Boolean
        If struser = user And strpass = pass Then
            Return True
        Else
            Return False



        End If
    End Function










End Class
