﻿Public Class Form1

    Dim intattempt As Integer = 0



    Private Sub btnlogin_Click(sender As Object, e As EventArgs) Handles btnlogin.Click
        Dim strusername As String = txtusername.Text
        Dim strpassword As String = txtpassword.Text


        Dim objloginverify As New userlogin

        If objloginverify.login(strusername, strpassword) = True Then
            MessageBox.Show("you have successfully logged in")
        Else
            MessageBox.Show("your username or passwprd, try again")
            intattempt += 1




        End If
        MessageBox.Show(intattempt)


        If intattempt = 3 Then
            MessageBox.Show("you have reached the limit of your login attemptes ")
            End
        End If


    End Sub
End Class
