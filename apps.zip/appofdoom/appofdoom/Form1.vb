﻿Public Class F1
    Private Sub btn1_Click(sender As Object, e As EventArgs) Handles btn1.Click
        Dim intnum As Integer
        Dim rndnumber As Random
        Dim intext As Integer
        Dim strresponse As String


        rndnumber = New Random

        intnum = rndnumber.Next(1, 11)
        intext = Val(Txt1.Text)
        Lbl1.Text = intnum.ToString


        If intnum = intext Then
            strresponse = "you win"
        ElseIf intext < intnum Then
            strresponse = "too low"
        Else
            strresponse = "too high"





        End If
        Lbl1.Text = strresponse
    End Sub
End Class
