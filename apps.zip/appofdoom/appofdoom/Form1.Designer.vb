﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class F1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btn1 = New System.Windows.Forms.Button()
        Me.Lbl1 = New System.Windows.Forms.Label()
        Me.Txt1 = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'btn1
        '
        Me.btn1.Location = New System.Drawing.Point(305, 177)
        Me.btn1.Name = "btn1"
        Me.btn1.Size = New System.Drawing.Size(137, 77)
        Me.btn1.TabIndex = 0
        Me.btn1.Text = "Button1"
        Me.btn1.UseVisualStyleBackColor = True
        '
        'Lbl1
        '
        Me.Lbl1.Location = New System.Drawing.Point(285, 335)
        Me.Lbl1.Name = "Lbl1"
        Me.Lbl1.Size = New System.Drawing.Size(216, 86)
        Me.Lbl1.TabIndex = 1
        Me.Lbl1.Text = "Label1"
        '
        'Txt1
        '
        Me.Txt1.Location = New System.Drawing.Point(193, 74)
        Me.Txt1.Name = "Txt1"
        Me.Txt1.Size = New System.Drawing.Size(393, 20)
        Me.Txt1.TabIndex = 2
        '
        'F1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.appofdoom.My.Resources.Resources.dice5
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.Txt1)
        Me.Controls.Add(Me.Lbl1)
        Me.Controls.Add(Me.btn1)
        Me.Name = "F1"
        Me.Text = "no idea"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btn1 As Button
    Friend WithEvents Lbl1 As Label
    Friend WithEvents Txt1 As TextBox
End Class
