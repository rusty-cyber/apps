﻿Public Class doubledie
    Private Sub btnroll_Click(sender As Object, e As EventArgs) Handles btnroll.Click
        'variables 
        Dim intdie1 As Integer
        Dim intdie2 As Integer
        Dim inttotal As Integer
        Dim rndgenerator As Random

        rndgenerator = New Random

        intdie1 = rndgenerator.Next(1, 7)
        intdie2 = rndgenerator.Next(1, 7)

        picdie1.Image = ImageList1.Images(intdie1 - 1)
        picdie2.Image = ImageList1.Images(intdie2 - 1)

        inttotal = intdie1 + intdie2

        lbltotal.Text = inttotal.ToString




    End Sub

    Private Sub btnexit_Click(sender As Object, e As EventArgs) Handles btnexit.Click
        End
    End Sub
End Class
