﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class doubledie
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(doubledie))
        Me.picdie1 = New System.Windows.Forms.PictureBox()
        Me.picdie2 = New System.Windows.Forms.PictureBox()
        Me.lbltot = New System.Windows.Forms.Label()
        Me.lbltotal = New System.Windows.Forms.Label()
        Me.btnroll = New System.Windows.Forms.Button()
        Me.btnexit = New System.Windows.Forms.Button()
        Me.ImageList1 = New System.Windows.Forms.ImageList(Me.components)
        CType(Me.picdie1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picdie2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'picdie1
        '
        Me.picdie1.Location = New System.Drawing.Point(153, 52)
        Me.picdie1.Name = "picdie1"
        Me.picdie1.Size = New System.Drawing.Size(103, 91)
        Me.picdie1.TabIndex = 0
        Me.picdie1.TabStop = False
        '
        'picdie2
        '
        Me.picdie2.Location = New System.Drawing.Point(423, 52)
        Me.picdie2.Name = "picdie2"
        Me.picdie2.Size = New System.Drawing.Size(93, 90)
        Me.picdie2.TabIndex = 1
        Me.picdie2.TabStop = False
        '
        'lbltot
        '
        Me.lbltot.Location = New System.Drawing.Point(250, 208)
        Me.lbltot.Name = "lbltot"
        Me.lbltot.Size = New System.Drawing.Size(63, 12)
        Me.lbltot.TabIndex = 2
        Me.lbltot.Text = "result"
        '
        'lbltotal
        '
        Me.lbltotal.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lbltotal.Location = New System.Drawing.Point(319, 208)
        Me.lbltotal.Name = "lbltotal"
        Me.lbltotal.Size = New System.Drawing.Size(88, 13)
        Me.lbltotal.TabIndex = 3
        '
        'btnroll
        '
        Me.btnroll.Location = New System.Drawing.Point(187, 261)
        Me.btnroll.Name = "btnroll"
        Me.btnroll.Size = New System.Drawing.Size(78, 45)
        Me.btnroll.TabIndex = 4
        Me.btnroll.Text = "roll"
        Me.btnroll.UseVisualStyleBackColor = True
        '
        'btnexit
        '
        Me.btnexit.Location = New System.Drawing.Point(416, 261)
        Me.btnexit.Name = "btnexit"
        Me.btnexit.Size = New System.Drawing.Size(100, 44)
        Me.btnexit.TabIndex = 5
        Me.btnexit.Text = "exit"
        Me.btnexit.UseVisualStyleBackColor = True
        '
        'ImageList1
        '
        Me.ImageList1.ImageStream = CType(resources.GetObject("ImageList1.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.ImageList1.TransparentColor = System.Drawing.Color.Transparent
        Me.ImageList1.Images.SetKeyName(0, "dice1.JPG")
        Me.ImageList1.Images.SetKeyName(1, "dice2.JPG")
        Me.ImageList1.Images.SetKeyName(2, "dice3.JPG")
        Me.ImageList1.Images.SetKeyName(3, "dice4.JPG")
        Me.ImageList1.Images.SetKeyName(4, "dice5.JPG")
        Me.ImageList1.Images.SetKeyName(5, "dice6.JPG")
        '
        'doubledie
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.btnexit)
        Me.Controls.Add(Me.btnroll)
        Me.Controls.Add(Me.lbltotal)
        Me.Controls.Add(Me.lbltot)
        Me.Controls.Add(Me.picdie2)
        Me.Controls.Add(Me.picdie1)
        Me.Name = "doubledie"
        Me.Text = "doulbe die "
        CType(Me.picdie1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picdie2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents picdie1 As PictureBox
    Friend WithEvents picdie2 As PictureBox
    Friend WithEvents lbltot As Label
    Friend WithEvents lbltotal As Label
    Friend WithEvents btnroll As Button
    Friend WithEvents btnexit As Button
    Friend WithEvents ImageList1 As ImageList
End Class
